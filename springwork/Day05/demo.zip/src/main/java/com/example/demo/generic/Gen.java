package com.example.demo.generic;

public class Gen<T> {
	T value; // 이변수의 타입을 Gen 객체가 만들어짐
	
}
