//package com.example.demo.di4;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import lombok.RequiredArgsConstructor; //생성자 생성
//
////코딩을 하려면 컴퓨터가 필요하다.
//@Component
//@RequiredArgsConstructor
//public class Coding {
//	
//	//final이나 @NonNull 붙이고 
//	private final Computer computer;
//	
//	
//}
//
//
